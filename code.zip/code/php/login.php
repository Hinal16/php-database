<?php


if($_SERVER['REQUEST_METHOD']=='POST'){
        echo $name = $_POST['name'];
        echo $password = $_POST['password'];
} 

//Connect to the database

$servername="localhost";
$username="root";
$password="";
$database="project";

$conn= mysqli_connect($servername,$username,$password,$database);

if(!$conn){
    die("Connection failed___".mysqli_connect_error());
    }
    else{
        //Insert data into database
        date_default_timezone_set("Asia/Kolkata").   //foe current time
    $timestamp=  date("Y-m-d h:i:sa");
    $sql="INSERT INTO `login` (`name`, `password`,`timestamp`) VALUES ( '$name','$password','$timestamp')";
    $result=mysqli_query($conn,$sql);

    
    
    }
    ($conn);
?>
    

