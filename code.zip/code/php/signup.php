<?php


if($_SERVER['REQUEST_METHOD']=='POST'){
        echo $name = $_POST['name'];
        echo $email = $_POST['email'];
        echo $password = $_POST['password'];  //password_hash( $_POST['password'],PASSWORD_DEFAULT)
        echo $role = $_POST['role'];
} 

//Connect to the database

$servername="localhost";
$username="root";
$password="";
$database="project";

$conn= mysqli_connect($servername,$username,$password,$database);

if(!$conn){
    die("Connection failed___".mysqli_connect_error());
    }
    else{
        echo "Connection successful";
        
        
        //Insert data into database   
    $sql="INSERT INTO `signup` (`name`, `email`, `password`,`role`) VALUES ( '$name', '$email', '$password','$role')";
    $result=mysqli_query($conn,$sql);

    if($result){
        echo"The database is added successfully";
              
                if($role =='customer'){
                    header ("Location: ../c_profile.html");
                }
                else{
                    header ("Location: ../d_profile.html");
                }
            }
    else{
        echo"<br>not inserted !!!". mysqli_error($conn);
        ($conn);
    }
    
    }


?>
    

