<?php


if($_SERVER['REQUEST_METHOD']=='POST'){
        echo $name = $_POST['name'];
        echo $email = $_POST['email'];
        echo $phone = $_POST['phone'];
        echo $address = $_POST['address'];
        echo $location = $_POST['location'];
        echo $services = $_POST['services'];
        echo $password = $_POST['password'];
} 

//Connect to the database

$servername="localhost";
$username="root";
$password="";
$database="project";

$conn= mysqli_connect($servername,$username,$password,$database);

if(!$conn){
    die("Connection failed___".mysqli_connect_error());
    }
    else{
        echo "Connection successful";
        //Insert data into database

        $hash = password_hash($password,PASSWORD_DEFAULT);
    $sql="INSERT INTO `c_profile` (`name`,`email`,`phone`,`address`,`location`,`services`, `password`) VALUES ( '$name','$email','$phone','$address','$location','$services','$hash')";
    $result=mysqli_query($conn,$sql);

    if($result){
        echo"The database is added successfully";
    }
    else{
        echo "The record was not inserted successfully because of this error ---> ". mysqli_error($conn);
}
        ($conn);
    }
    
?>
    

