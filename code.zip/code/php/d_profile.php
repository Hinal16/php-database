<?php


if($_SERVER['REQUEST_METHOD']=='POST'){
        echo $name = $_POST['name'];
        echo $email = $_POST['email'];
        echo $phone = $_POST['phone'];
        echo $password = $_POST['password'];
        echo $office_address = $_POST['office_address'];
        echo $past_project = $_POST['past_project'];
        echo $specialities = $_POST['specialities'];
        echo $business_info = $_POST['business_info'];
} 

//Connect to the database

$servername="localhost";
$username="root";
$password="";
$database="project";

$conn= mysqli_connect($servername,$username,$password,$database);

if(!$conn){
    die("Connection failed___".mysqli_connect_error());
    }
    else{
        echo "Connection successful";
        //Insert data into database

    
    $sql="INSERT INTO `d_profile` (`name`,`email`,`phone`,`password`,`office_address`,`past_project`,`specialities`, `business_info`) VALUES ( '$name','$email','$phone','$password','$office_address','$past_project','$specialities','$business_info')";
    $result=mysqli_query($conn,$sql);

    if($result){
        echo"The database is added successfully";
    }
    else{
        echo"not inserted !!!";
        ($conn);
    }
    }
?>
    

