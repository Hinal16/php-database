<?php


if($_SERVER['REQUEST_METHOD']=='POST'){
        echo $name = $_POST['name'];
        echo $email = $_POST['email'];
        echo $password = $_POST['password'];
} 

//Connect to the database

$servername="localhost";
$username="root";
$password="";
$database="project";

$conn= mysqli_connect($servername,$username,$password,$database);

if(!$conn){
    die("Connection failed___".mysqli_connect_error());
    }
    else{
        echo "Connection successful<br>";
        
    }
    //select data into database
      
    $sql="SELECT * FROM `c_profile`";
    $result= mysqli_query($conn,$sql);

   // $num = mysqli_num_rows($result);
    //echo $num;
   // echo "<br>";

    
//if($num>0){
    while($row = mysqli_fetch_assoc($result)){
       // $row=mysqli_fetch_assoc($result);
   
    echo $row['id'] . "\t" . $row['name']."\t" . $row['email'] ."\t" .$row['phone']."\t" .$row['address']."\t" .$row['location']."\t" .$row['password']."\t" . $row['services'];
    echo "<br>";

    }
//}
  
          //update database
          $id=$_GET['id'];
          $sql= "UPDATE `c_profile` WHERE `c_profile`.`id` = $id";
          $result= mysqli_query($conn,$sql);
           
          if($result){
            echo "We updated the record successfully";
        }
        else{
            echo "We could not update the record successfully";
        }
    ?>