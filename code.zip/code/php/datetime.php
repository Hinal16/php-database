<?php


date_default_timezone_set("Asia/Kolkata");
echo date("Y-m-d h:i:sa");


?>