<?php

//Connect to the database

$servername="localhost";
$username="root";
$password="";
$database="project";

$conn= mysqli_connect($servername,$username,$password,$database);

if(!$conn){
    die("Connection failed___".mysqli_connect_error());
    }
    else{
        echo "Connection successful";
    }
?>